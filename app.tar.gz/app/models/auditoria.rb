class Auditoria < ActiveRecord::Base
	self.table_name = "AUDITORIA"
end
