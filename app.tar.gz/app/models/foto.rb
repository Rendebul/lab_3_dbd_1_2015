class Foto < ActiveRecord::Base
	self.table_name = "FOTO"
	
end
