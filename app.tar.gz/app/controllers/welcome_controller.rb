class WelcomeController < ApplicationController
  def index
  end
  def create
  	
  end
  
end
